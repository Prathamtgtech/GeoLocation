package com.example.geolocation.HomeButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.geolocation.R;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationAvailability;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;

import org.jetbrains.annotations.NotNull;

import static android.content.ContentValues.TAG;
import static com.google.android.gms.location.LocationRequest.*;

public class CurrentLocation extends AppCompatActivity {
    Button getloc;
    TextView lattxt, langtxt, latval, langval;
    FusedLocationProviderClient fusedLocationProviderClient;
    LocationRequest locationRequest;
    Location CurrentLocations;
    LocationCallback locationCallback;
    public static int INTERVAL_TIME = 5000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_current_location);
        getloc = findViewById(R.id.getLoc);
        lattxt = findViewById(R.id.lattxt);
        latval = findViewById(R.id.latvalue);
        langtxt = findViewById(R.id.langtxt);
        langval = findViewById(R.id.langvalue);
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        locationRequest = LocationRequest.create();
        locationRequest.setPriority(PRIORITY_HIGH_ACCURACY);
        locationRequest.setInterval(INTERVAL_TIME);
        locationCallback = new LocationCallback() {
            @Override
            public void onLocationAvailability(LocationAvailability locationAvailability) {
                super.onLocationAvailability(locationAvailability);
                if (locationAvailability.isLocationAvailable()) {
                    Log.d(TAG, "Location Is Available");
                } else {
                    Log.d(TAG, "Location is available");
                }
            }

            @Override
            public void onLocationResult(LocationResult locationResult) {
                super.onLocationResult(locationResult);
                Log.d(TAG, "Location Result");
            }
        };
        //Get Current Location
        getloc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ActivityCompat.checkSelfPermission(CurrentLocation.this, Manifest.permission.ACCESS_FINE_LOCATION)== PackageManager.PERMISSION_GRANTED &&
                        (ActivityCompat.checkSelfPermission(CurrentLocation.this,Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED)){
                    fusedLocationProviderClient.requestLocationUpdates(locationRequest,locationCallback,CurrentLocation.this.getMainLooper());
                    fusedLocationProviderClient.getLastLocation().addOnSuccessListener(new OnSuccessListener<Location>() {
                        @Override
                        public void onSuccess(Location location) {
                            CurrentLocations =location;
                            latval.setText(""+CurrentLocations.getLatitude());
                            langval.setText(""+CurrentLocations.getLatitude());
                        }
                    });

                    fusedLocationProviderClient.getLastLocation().addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NotNull Exception e) {
                            Log.d(TAG,"Not Location Detect Allow Permission");
                        }
                    });
                }

            }
        });
    }
//Current Location
    private void MyCo() {

}
}