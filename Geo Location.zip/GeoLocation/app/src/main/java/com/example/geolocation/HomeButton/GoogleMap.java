package com.example.geolocation.HomeButton;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.geolocation.R;

public class GoogleMap extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_google_map);
    }
}